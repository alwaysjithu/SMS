<?php

namespace Database\Seeders;

use App\Models\Mark;
use App\Models\Student;
use App\Models\Teacher;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        Schema::disableForeignKeyConstraints();
        DB::table('teachers')->truncate();
        DB::table('students')->truncate();
        DB::table('marks')->truncate();
        Schema::enableForeignKeyConstraints();

        Teacher::factory(10)
            ->has(Student::factory()->count(1))
            ->create();

        for ($i = 1; $i <= 10; $i++) {
            $terms = ['One', 'Two'];
            foreach ($terms as $term)
                Mark::factory(1)->state([
                    'student_id' => $i,
                    'term' => $term
                ])->create();
        }
    }
}
