<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class MarkFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'maths' => $this->faker->numberBetween(35, 80),
            'science' => $this->faker->numberBetween(35, 80),
            'history' => $this->faker->numberBetween(35, 80)
        ];
    }
}
