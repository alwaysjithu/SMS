@if (session('success') || session('error') || session('status'))
<div role="alert"
    class="alert alert-dismissible fade show @if (session('success')) alert-success @elseif(session('error')) alert-danger @elseif(session('status')) alert-info @endif ">
    @if (session('success'))
    {{ session('success') }}
    @elseif(session('error'))
    {{ session('error') }}
    @elseif(session('status'))
    {{ session('status') }}
    @endif
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
@endif