@extends('layouts.app')

@section('title', 'Home')

@section('content')
<div class="card text-center">
    <div class="card-body">
        <h5 class="card-title">Home Page</h5>
        <p class="card-text">Welcome to the app</p>
        <a href="{{ route('student.index') }}" class="card-link">Student</a>
    </div>
</div>
@endsection