@extends('layouts.app')

@section('title', 'Add mark')

@section('content')
<div class="row">
    <div class="col-8">
        <h4 class="m-0">Add mark</h4>
    </div>
    <div class="col-4 text-end">
        <a href="{{ route('student.show',$id) }}" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-long-arrow-alt-left fa-fw mr-2"></i>Go Back
        </a>
    </div>
</div>
<hr>

<div class="row justify-content-center">
    <div class="col-6">
        <div class="card">
            <div class="card-body">
                <form action="{{ route('storeMark',$id) }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="maths" class="form-label">Maths</label>
                        <input type="number" class="form-control @error('maths') is-invalid @enderror" id="maths"
                            name="maths" value="{{old('maths')}}" required autofocus>
                        @error('maths')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="science" class="form-label">Science</label>
                        <input type="number" class="form-control @error('science') is-invalid @enderror" id="science"
                            name="science" value="{{old('science')}}" required>
                        @error('science')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="history" class="form-label">History</label>
                        <input type="number" class="form-control @error('history') is-invalid @enderror" id="history"
                            name="history" value="{{old('history')}}" required>
                        @error('history')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="term" class="form-label">Term</label>
                        <select class="form-select @error('term') is-invalid @enderror" name='term' id='term' required>
                            <option selected>Choose a term</option>
                            <option value="One" {{ old('term')=='One' ? 'selected' : '' }}>One</option>
                            <option value="Two" {{ old('term')=='Two' ? 'selected' : '' }}>Two</option>
                        </select>
                        @error('term')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="text-end">
                        <a href="{{ route('student.show',$id) }}" class="btn btn-link">Cancel</a>
                        <button type="submit" class="btn btn-outline-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection