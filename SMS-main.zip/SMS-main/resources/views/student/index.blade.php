@extends('layouts.app')

@section('title', 'Students')

@section('content')
<div class="row">
    <div class="col-8">
        <h4 class="m-0">Students</h4>
    </div>
    <div class="col-4 text-end">
        <a href="{{ route('home') }}" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-long-arrow-alt-left fa-fw mr-2"></i>Go Home
        </a>
        <a href="{{ route('student.create') }}" class="btn btn-dark btn-sm">
            <i class="fas fa-plus-circle fa-fw mr-2"></i>Add New
        </a>
    </div>
</div>
<hr>

<table class="table table-bordered table-hover align-middle">
    <thead class="table-light">
        <tr>
            <th>#</th>
            <th>Name</th>
            <th class="text-center">Age</th>
            <th>Gender</th>
            <th>Teacher</th>
            <th class="text-center">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($result as $row)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>
                <a href="{{ route('student.show',$row['id']) }}" class="btn btn-link">{{ $row['name'] }}</a>
            </td>
            <td class="text-center">{{ $row['age'] }}</td>
            <td>{{ $row['gender']}}</td>
            <td>{{ $row['teacher']['name']}}</td>
            <td class="text-center">
                <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                    <a href="#" class="btn btn-outline-secondary">Edit</a>
                    <button type="button" class="btn btn-outline-danger">Delete</button>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection