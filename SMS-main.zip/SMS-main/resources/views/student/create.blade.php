@extends('layouts.app')

@section('title', 'New Student')

@section('content')
<div class="row">
    <div class="col-8">
        <h4 class="m-0">New Student</h4>
    </div>
    <div class="col-4 text-end">
        <a href="{{ route('student.index') }}" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-long-arrow-alt-left fa-fw mr-2"></i>Go Back
        </a>
    </div>
</div>
<hr>

<div class="row justify-content-center">
    <div class="col-6">
        <div class="card">
            <div class="card-body">
                <form action="{{ route('student.store') }}" method="POST">
                    @csrf
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" id="name"
                            name="name" value="{{old('name')}}" required autofocus>
                        @error('name')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="age" class="form-label">Age</label>
                        <input type="number" class="form-control @error('age') is-invalid @enderror" id="age" name="age"
                            value="{{old('age')}}" required>
                        @error('age')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="male" value="Male" required
                                {{ old('gender')=='Male' ? 'checked' : '' }}>
                            <label class="form-check-label" for="male">Male</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="gender" id="female" value="Female"
                                required {{ old('gender')=='Female' ? 'checked' : '' }}>
                            <label class="form-check-label" for="female">Female</label>
                        </div>
                        @error('gender')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="mb-3">
                        <label for="teacher" class="form-label">Teacher</label>
                        <select class="form-select @error('teacher') is-invalid @enderror" name='teacher' id='teacher' required>
                            <option>Choose teacher</option>
                            @foreach($teachers as $row)
                            <option value="{{ $row['id'] }}" {{ old('teacher')==$row['id'] ? 'selected' : '' }}>
                                {{ $row['name'] }}
                            </option>
                            @endforeach
                        </select>
                        @error('teacher')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="text-end">
                        <a href="{{ route('student.index') }}" class="btn btn-link">Cancel</a>
                        <button type="submit" class="btn btn-outline-success">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection