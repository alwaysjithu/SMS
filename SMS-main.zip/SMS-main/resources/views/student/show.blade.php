@extends('layouts.app')

@section('title', 'Student Details')

@section('content')
<div class="row">
    <div class="col-8">
        <h4 class="m-0">Student Details</h4>
    </div>
    <div class="col-4 text-end">
        <a href="{{ route('student.index') }}" class="btn btn-outline-primary btn-sm">
            <i class="fas fa-long-arrow-alt-left fa-fw mr-2"></i>Go Back
        </a>
        <a href="{{ route('addMark',$id) }}" class="btn btn-dark btn-sm">
            <i class="fas fa-plus-circle fa-fw mr-2"></i>Add Mark
        </a>
    </div>
</div>
<hr>

<table class="table table-bordered table-hover align-middle">
    <thead class="table-light">
        <tr>
            <th>#</th>
            <th>Name</th>
            <th class="text-center">Maths</th>
            <th class="text-center">Science</th>
            <th class="text-center">History</th>
            <th class="text-center">Term</th>
            <th class="text-center">Total marks</th>
            <th>Created On</th>
            <th class="text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($marks as $row)
        <tr>
            <td>{{ $loop->iteration }}</td>
            <td>{{ $name }}</td>
            <td class="text-center">{{ $row['maths'] }}</td>
            <td class="text-center">{{ $row['science'] }}</td>
            <td class="text-center">{{ $row['history'] }}</td>
            <td class="text-center">{{ $row['term'] }}</td>
            <td class="text-center">{{ $row['maths'] + $row['science'] + $row['history'] }}</td>
            <td>{{ \Illuminate\Support\Carbon::parse($row['created_at'])->format('M d, Y, h:i A') }}</td>
            <td class="text-center">
                <div class="btn-group btn-group-sm" role="group" aria-label="Basic example">
                    <a href="#" class="btn btn-outline-secondary">Edit</a>
                    <button type="button" class="btn btn-outline-danger">Delete</button>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@endsection