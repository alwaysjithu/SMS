<?php

use App\Http\Controllers\StudentController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome')->name('home');

Route::get('student/{id}/mark', [StudentController::class, 'addMark'])->name('addMark');

Route::post('student/{id}/mark', [StudentController::class, 'storeMark'])->name('storeMark');

Route::resource('student', StudentController::class)->except([
    'edit', 'update', 'delete'
]);
