<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Exception;

class StudentController extends Controller
{
    /**
     * Display a listing of the student.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $result = Student::with('teacher')->get();
            return view('student.index', compact('result'));
        } catch (Exception $e) {
            return redirect()->route('home')->with('error', $e->getMessage());
        }
    }

    /**
     * Show the form for creating a new student.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $teachers = Teacher::all();
        return view('student.create', compact('teachers'));
    }

    /**
     * Store a newly created student in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'age' => 'required|numeric|min:20|max:50',
            'gender' => 'required|in:Male,Female',
            'teacher' => 'required|exists:App\Models\Teacher,id'
        ]);

        try {
            Student::create([
                'name' => $request->name,
                'age' => $request->age,
                'gender' => $request->gender,
                'teacher_id' => $request->teacher
            ]);
            return redirect(route('student.index'))->with('success', 'Student created successfully');
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Display the specified student.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $student = Student::find($id);
            if ($student)
                return view('student.show', $student->load('marks'));
            return redirect(route('student.index'))->with('error', 'Student not found');
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Display the specified student mark form.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function addMark($id)
    {
        try {
            $student = Student::find($id);
            if ($student)
                return view('student.addMark', $student);
            return redirect(route('student.index'))->with('error', 'Student not found');
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /**
     * Store a student in mark.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function storeMark(Request $request, $id)
    {
        $request->validate([
            'maths' => 'required|numeric|min:0|max:100',
            'science' => 'required|numeric|min:0|max:100',
            'history' => 'required|numeric|min:0|max:100',
            'term' => 'required|in:One,Two'
        ]);

        try {
            $student = Student::find($id);
            if ($student) {
                $student->marks()->create([
                    'maths' => $request->maths,
                    'science' => $request->science,
                    'history' => $request->history,
                    'term' => $request->term
                ]);
                return redirect(route('student.show', $id))->with('success', 'Mark stored successfully');
            }
            return redirect(route('student.index'))->with('error', 'Student not found');
        } catch (Exception $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
